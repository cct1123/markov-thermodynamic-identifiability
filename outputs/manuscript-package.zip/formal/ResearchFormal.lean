import ResearchFormal.Smoke
